#include "room_control.h"

#include "gpio.h"
#include "systick.h"
#include "uart.h"
#include "tim.h"
#include <stdio.h>

// --------------------
// Definición de estados
// --------------------
typedef enum {
    ROOM_IDLE,
    ROOM_OCCUPIED
} room_state_t;

// --------------------
// Variables globales
// --------------------
static room_state_t current_state = ROOM_IDLE;
static uint32_t led_on_timestamp = 0;
static uint8_t current_duty = PWM_INITIAL_DUTY;

// --------------------
// Inicialización
// --------------------
void room_control_app_init(void)
{
    current_state = ROOM_IDLE;
    tim3_ch1_pwm_set_duty_cycle(0);  // LED apagado
    uart_send_string("Sistema Room Control iniciado\r\n");
    uart_send_string("Estado inicial: Sala vacia\r\n");
}

// --------------------
// Manejador de botón
// --------------------
void room_control_on_button_press(void)
{
    if (current_state == ROOM_IDLE) {
        current_state = ROOM_OCCUPIED;
        uart_send_string("Boton: Sala ocupada\r\n");
        tim3_ch1_pwm_set_duty_cycle(100);
        gpio_write_pin(GPIOA, 5, 1); // LED encendido
        led_on_timestamp = systick_get_ms();
    } else {
        current_state = ROOM_IDLE;
        uart_send_string("Boton: Sala vacia\r\n");
        tim3_ch1_pwm_set_duty_cycle(0);
        gpio_write_pin(GPIOA, 5, 0); // LED apagado
    }
}

// --------------------
// Manejador de UART
// --------------------
void room_control_on_uart_receive(char received_char)
{
    static char last_char = 0;

    switch (received_char) {
        case 'h':
        case 'H':
            tim3_ch1_pwm_set_duty_cycle(100);
            uart_send_string("PWM al 100%\r\n");
            break;

        case 'l':
        case 'L':
            tim3_ch1_pwm_set_duty_cycle(0);
            uart_send_string("PWM al 0%\r\n");
            break;

        case 'O':
        case 'o':
            current_state = ROOM_OCCUPIED;
            uart_send_string("UART: Sala ocupada\r\n");
            tim3_ch1_pwm_set_duty_cycle(100);
            gpio_write_pin(GPIOA, 5, 1);
            led_on_timestamp = systick_get_ms();
            break;

        case 'I':
        case 'i':
            current_state = ROOM_IDLE;
            uart_send_string("UART: Sala vacia\r\n");
            tim3_ch1_pwm_set_duty_cycle(0);
            gpio_write_pin(GPIOA, 5, 0);
            break;

        default:
            // Soporte para comandos tipo "B5" -> 50%
            if (last_char == 'B' && received_char >= '0' && received_char <= '9') {
                uint8_t duty = (received_char - '0') * 10;
                tim3_ch1_pwm_set_duty_cycle(duty);
                char msg[32];
                sprintf(msg, "PWM ajustado al %u%%\r\n", duty);
                uart_send_string(msg);
            } else {
                // Eco normal
                uart_send_char(received_char);
            }
            break;
    }

    last_char = received_char;
}

// --------------------
// Actualización periódica
// --------------------
void room_control_update(void)
{
    uint32_t now = systick_get_ms();

    if (current_state == ROOM_OCCUPIED) {
        if ((now - led_on_timestamp) >= LED_TIMEOUT_MS) {
            current_state = ROOM_IDLE;
            tim3_ch1_pwm_set_duty_cycle(0);
            gpio_write_pin(GPIOA, 5, 0);
            uart_send_string("Timeout: LED apagado, sala vacia\r\n");
        }
    }
}
